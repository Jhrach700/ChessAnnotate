import NFTBalance from "components/NFTBalance";
import React from "react";

function nftBalance() {
	return <NFTBalance />;
}

export default nftBalance;
