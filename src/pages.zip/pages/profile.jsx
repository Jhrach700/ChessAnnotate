import Profile2 from "components/Profile"
import React from "react";
import { useMoralis } from "react-moralis";
function Profile() {
	const { Moralis, enableWeb3 } = useMoralis();
	const addr = Moralis.User.current().attributes.ethAddress
	return <Profile2 wallet_addr = {addr} />;
}

export default Profile;
