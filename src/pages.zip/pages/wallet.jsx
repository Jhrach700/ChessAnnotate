import Wallet from 'components/Wallet/Wallet';
import React from 'react'

function wallet() {
    return <Wallet/>
}

export default wallet
