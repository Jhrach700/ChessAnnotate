import Profile2 from "components/Profile"
import React from "react";

function Profile() {
	return <Profile2 />;
}

export default Profile;
