import { useMoralis } from "react-moralis";
import { useState, useEffect } from "react";



//useEffect(() => {
//    var m = init()
//});
//
//async function init() {
//    const { Moralis } = await useMoralis();
//    return Moralis
//}

export const useAPIContract = async () => {
    const { Moralis } = useMoralis();
    const Games = Moralis.Object.extend("Game");
    const query = new Moralis.Query(Games);
    const results = await query.find();
    console.log("RESULTS:", results)
    const paths2 = results.map(re => {
        return {
            params: { id: re.id.toString() }
        }
    })
    return paths2;
};


export async function getStaticPaths() {
    //const { Moralis } = await useMoralis();
    //const { Moralis, enableWeb3 } = useMoralis();
    
    //const pts = useAPIContract()
    //console.log("PTS:",pts)

    const res = await fetch('https://jsonplaceholder.typicode.com/users');
    const data = await res.json();

    // map data to an array of path objects with params (id)
    const paths = data.map(ninja => {
        return {
            params: { id: ninja.id.toString() }
        }
    })

    return {
        pts,
        fallback: false
    }
}

export const getStaticProps = async (context) => {
    const id = context.params.id;
    const res = await fetch('https://jsonplaceholder.typicode.com/users/' + id);
    const data = await res.json();

    return {
        props: { ninja: data }
    }
}

const Details = ({ ninja }) => {
    return (
        <div>
            <h1>{ninja.name}</h1>
            <p>{ninja.email}</p>
            <p>{ninja.website}</p>
            <p>{ninja.address.city}</p>
        </div>
    );
}

export default Details;