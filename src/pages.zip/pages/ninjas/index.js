import Link from 'next/link'
import { useMoralis } from "react-moralis";
//import { useEffect, useState } from "react";


export async function useERC20Balance() {
  //const { account } = useMoralisWeb3Api();
  const { isInitialized, chainId, account: walletAddress } = useMoralis();
  //const [Games, setGames] = useState([]);

  const [assets, setAssets] = useState();

  useEffect(() => {
    if (isInitialized) {
      fetch().then((balance) => {
        setAssets(balance)
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isInitialized, chainId, walletAddress]);


  async function fetch() {
    const { Moralis } = useMoralis();
    const Games = Moralis.Object.extend("Game");
    const query = new Moralis.Query(Games);
    const results = await query.find();
    console.log("RESULTS:", results)
    const paths2 = results.map(re => {
      return {
        params: { id: re.id.toString() }
      }
    })
    return paths2;
  }

  // const fetchERC20Balance = async () => {
  //   return await account
  //     .getTokenBalances({ address: walletAddress, chain: params?.chain || chainId })
  //     .then((result) => result);
  // };

  return { assets };
};


// const getPosts = () =>
//   fetch('https://api.github.com/repos/tannerlinsley/react-query').then((res) =>
//     res.json()
//   )

// export async function getServerSideProps(context) {
//   const queryCache = new QueryCache()
//   await queryCache.prefetchQuery('posts', getPosts)

//   return {
//     props: {
//       dehydratedState: dehydrate(queryCache),
//     },
//   }
// }


export async function getStaticProps() {
  const res = await fetch('https://jsonplaceholder.typicode.com/users');
  const data = await res.json();
  return {
    props: { ninjas: data }
  }
}

const Ninjas = ({ ninjas }) => {
  // console.log(ninjas)

  return (
    <div>
      <h1>All Ninjas</h1>
      {ninjas.map(ninja => (
        <Link href={'/ninjas/' + ninja.id} key={ninja.id}>
          <a>
            <h3>{ninja.id}</h3>
          </a>
        </Link>
      ))}
    </div>
  );
}

export default Ninjas;