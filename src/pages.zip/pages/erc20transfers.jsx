import ERC20Transfers from "components/ERC20Transfers/ERC20Transfers";
import React from "react";

function erc20transfers() {
	return <ERC20Transfers />;
}

export default erc20transfers;
