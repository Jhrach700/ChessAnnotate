import React from "react";
import ERC20Balance from "components/ERC20Balance";

function erc20balance() {
	return <ERC20Balance />;
}

export default erc20balance;
