import GameList from "components/GameList"
import React from "react";

function Games() {
	return <GameList requester_wallet_address={null} />;
}

export default Games;
