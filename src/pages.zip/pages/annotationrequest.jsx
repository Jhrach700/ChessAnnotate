import AnnotationRequst from "components/AnnotationRequests"
import React from "react";

function AnnotationRequsts() {
	return <AnnotationRequst />;
}

export default AnnotationRequsts;
