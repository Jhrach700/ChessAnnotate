import React from "react";
import QuickStart from "components/QuickStart";

export default function quickstart({ isServerInfo }) {
	return <QuickStart isServerInfo={isServerInfo} />;
}
