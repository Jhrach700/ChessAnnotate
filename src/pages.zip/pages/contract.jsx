import Contract from "components/Contract/Contract";
import React from "react";

function contract() {
	return <Contract />;
}

export default contract;
