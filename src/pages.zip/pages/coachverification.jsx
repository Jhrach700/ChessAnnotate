import CoachVerification from "components/CoachVerification"
import React from "react";

function CoachVerifications() {
	return <CoachVerification />;
}

export default CoachVerifications;
