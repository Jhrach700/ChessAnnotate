import Wallet2 from 'components/Wallet2/Wallet2';
import React from 'react'

function wallet2() {
    return <Wallet2/>
}

export default wallet2
