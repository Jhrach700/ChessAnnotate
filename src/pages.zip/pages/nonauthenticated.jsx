import React from "react";

function nonauthenticated() {
	return (
		<div>
			<>Please login using the &quot;Authenticate&quot; button</>
		</div>
	);
}

export default nonauthenticated;
