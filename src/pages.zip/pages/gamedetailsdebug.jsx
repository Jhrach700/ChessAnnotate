import GameDetailsDebug from "components/GameDetailsDebug/GameDetailsDebug"
import React from "react";

function GameDetailsDebugs() {
	return <GameDetailsDebug />;
}

export default GameDetailsDebugs;
