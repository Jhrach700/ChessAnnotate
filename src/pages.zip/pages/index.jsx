import React from "react";

function Index() {
	return <div>Pppf!!</div>;
}

export default Index;
